"""NOS Codeblock Module."""
